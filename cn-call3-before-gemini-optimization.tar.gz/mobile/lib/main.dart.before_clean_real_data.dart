import 'dart:async';
import 'package:flutter/material.dart';

import 'services/call_session.dart';
import 'services/account_api.dart';
import 'services/rtc_call_manager.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:shared_preferences/shared_preferences.dart';
void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const CNCallApp());
}

class CNCallApp extends StatefulWidget {
  const CNCallApp({super.key});

  @override
  State<CNCallApp> createState() => _CNCallAppState();
}

class _CNCallAppState extends State<CNCallApp> {
  bool _loading = true;
  bool _hasSession = false;

  @override
  void initState() {
    super.initState();
    _restoreSession();
  }

  Future<void> _restoreSession() async {
    final restored = await CallSession.instance.restoreSession();

    if (!mounted) return;

    setState(() {
      _hasSession = restored;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'CN CALL',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF050505),
        useMaterial3: true,
      ),
      home: _loading
          ? const Scaffold(
              body: Center(
                child: CircularProgressIndicator(
                  color: Color(0xFF00E676),
                ),
              ),
            )
          : _hasSession
              ? const HomeScreen()
              : const LoginScreen(),
    );
  }
}

// ============================================================
// LOGIN
// ============================================================

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final userIdController = TextEditingController();
  final passwordController = TextEditingController();

  bool hidePassword = true;

  @override
  void dispose() {
    userIdController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  void openRegister() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const RegisterScreen(),
      ),
    );
  }

  Future<void> login() async {
    final userId = userIdController.text.trim();
    final password = passwordController.text;

    if (userId.isEmpty) {
      _message('أدخل ID المستخدم');
      return;
    }

    if (int.tryParse(userId) == null) {
      _message('ID المستخدم يجب أن يكون أرقامًا فقط');
      return;
    }

    if (password.isEmpty) {
      _message('أدخل كلمة المرور');
      return;
    }

    final result = await AccountApi.login(
      userId: userId,
      password: password,
    );

    if (!mounted) return;

    final success = result['success'] == true;

    if (!success) {
      _message(
        result['message']?.toString() ??
            'ID المستخدم أو كلمة المرور غير صحيحة',
      );
      return;
    }

    final user = result['user'];

    if (user is! Map) {
      _message('بيانات المستخدم غير صالحة');
      return;
    }

    final loggedUserId = user['user_id']?.toString();
    final username = user['username']?.toString();

    if (loggedUserId == null ||
        loggedUserId.isEmpty ||
        username == null ||
        username.isEmpty) {
      _message('بيانات المستخدم ناقصة');
      return;
    }

    CallSession.instance.login(
      id: loggedUserId,
      name: username,
    );

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => const HomeScreen(),
      ),
    );
  }

  void _message(String text, {bool success = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor:
            success ? const Color(0xFF00A85A) : Colors.red.shade800,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(
                horizontal: 24,
                vertical: 40,
              ),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: Column(
                  children: [
                    _Logo(),

                    const SizedBox(height: 24),

                    const Text(
                      'CN CALL',
                      style: TextStyle(
                        fontSize: 34,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 2,
                      ),
                    ),

                    const SizedBox(height: 8),

                    Text(
                      'مكالمات صوتية بدون أرقام هاتف',
                      style: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 14,
                      ),
                    ),

                    const SizedBox(height: 42),

                    _Field(
                      controller: userIdController,
                      label: 'ID المستخدم',
                      hint: 'أدخل ID المستخدم',
                      icon: Icons.badge_outlined,
                      keyboardType: TextInputType.number,
                    ),

                    const SizedBox(height: 16),

                    _Field(
                      controller: passwordController,
                      label: 'كلمة المرور',
                      hint: 'أدخل كلمة المرور',
                      icon: Icons.lock_outline,
                      obscureText: hidePassword,
                      suffix: IconButton(
                        onPressed: () {
                          setState(() {
                            hidePassword = !hidePassword;
                          });
                        },
                        icon: Icon(
                          hidePassword
                              ? Icons.visibility_off
                              : Icons.visibility,
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    _PrimaryButton(
                      text: 'تسجيل الدخول',
                      onPressed: login,
                    ),

                    const SizedBox(height: 12),

                    SizedBox(
                      width: double.infinity,
                      height: 52,
                      child: OutlinedButton(
                        onPressed: openRegister,
                        style: OutlinedButton.styleFrom(
                          foregroundColor: Colors.white,
                          side: BorderSide(
                            color: Colors.grey.shade800,
                          ),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18),
                          ),
                        ),
                        child: const Text(
                          'إنشاء حساب جديد',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 28),

                    _Footer(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// HOME
// ============================================================

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final callIdController = TextEditingController();

  final List<Map<String, String>> _contacts = [];
  final List<Map<String, dynamic>> _callHistory = [];

  bool _loadingData = true;

  bool _incomingCallScreenOpen = false;

  @override
  void initState() {
    super.initState();

    _loadLocalData();

    final rtcManager = RtcCallManager.instance;
    rtcManager.startListening();

    rtcManager.onIncomingCall = (call) {
      if (!mounted) return;

      final callerId = call['from_id']?.toString() ?? '';
      final callerName =
          call['caller_name']?.toString() ?? 'مستخدم CN CALL';

      if (callerId.isEmpty) return;
      if (_incomingCallScreenOpen) return;

      _addHistory(
        name: callerName,
        id: callerId,
        incoming: true,
      );

      _incomingCallScreenOpen = true;

      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => IncomingCallScreen(
            name: callerName,
            id: callerId,
          ),
        ),
      ).then((_) {
        if (mounted) {
          _incomingCallScreenOpen = false;
        }
      });
    };
  }

  Future<void> _loadLocalData() async {
    final prefs = await SharedPreferences.getInstance();

    final contacts = prefs.getStringList('cn_call_contacts') ?? [];

    final loadedContacts = <Map<String, String>>[];

    for (final item in contacts) {
      final parts = item.split('|');

      if (parts.length >= 2) {
        loadedContacts.add({
          'id': parts[0],
          'name': parts.sublist(1).join('|'),
        });
      }
    }

    final history = prefs.getStringList('cn_call_history') ?? [];

    final loadedHistory = <Map<String, dynamic>>[];

    for (final item in history) {
      final parts = item.split('|');

      if (parts.length >= 4) {
        loadedHistory.add({
          'id': parts[0],
          'name': parts[1],
          'incoming': parts[2] == '1',
          'time': parts.sublist(3).join('|'),
        });
      }
    }

    if (!mounted) return;

    setState(() {
      _contacts
        ..clear()
        ..addAll(loadedContacts);

      _callHistory
        ..clear()
        ..addAll(loadedHistory);

      _loadingData = false;
    });
  }

  Future<void> _saveContacts() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setStringList(
      'cn_call_contacts',
      _contacts
          .map(
            (contact) =>
                '${contact['id']!}|${contact['name']!}',
          )
          .toList(),
    );
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setStringList(
      'cn_call_history',
      _callHistory
          .map(
            (item) =>
                '${item['id']}|${item['name']}|${item['incoming'] == true ? '1' : '0'}|${item['time']}',
          )
          .toList(),
    );
  }

  Future<void> _addHistory({
    required String name,
    required String id,
    required bool incoming,
  }) async {
    final now = DateTime.now();

    final time =
        '${now.day.toString().padLeft(2, '0')}/'
        '${now.month.toString().padLeft(2, '0')} '
        '${now.hour.toString().padLeft(2, '0')}:'
        '${now.minute.toString().padLeft(2, '0')}';

    final item = <String, dynamic>{
      'id': id,
      'name': name,
      'incoming': incoming,
      'time': time,
    };

    if (mounted) {
      setState(() {
        _callHistory.insert(0, item);

        if (_callHistory.length > 50) {
          _callHistory.removeLast();
        }
      });
    }

    await _saveHistory();
  }

  Future<void> _addContact() async {
    final result = await _showAddContactDialog(context);

    if (result == null) return;

    final id = result['id']!;
    final name = result['name']!;

    if (_contacts.any((contact) => contact['id'] == id)) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('جهة الاتصال موجودة بالفعل'),
        ),
      );

      return;
    }

    if (!mounted) return;

    setState(() {
      _contacts.add({
        'id': id,
        'name': name,
      });
    });

    await _saveContacts();

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تمت إضافة $name إلى جهات الاتصال'),
        backgroundColor: const Color(0xFF00A85A),
      ),
    );
  }

  Future<void> _deleteContact(String id) async {
    setState(() {
      _contacts.removeWhere(
        (contact) => contact['id'] == id,
      );
    });

    await _saveContacts();
  }

  Future<void> _clearHistory() async {
    setState(() {
      _callHistory.clear();
    });

    await _saveHistory();
  }

  Future<void> startCall() async {
    final id = callIdController.text.trim();

    if (id.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('أدخل ID المستخدم الذي تريد الاتصال به'),
        ),
      );
      return;
    }

    if (int.tryParse(id) == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('ID المستخدم يجب أن يكون أرقامًا فقط'),
        ),
      );
      return;
    }

    final session = CallSession.instance;

    if (!session.loggedIn) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('يجب تسجيل الدخول أولًا'),
        ),
      );
      return;
    }

    final name = 'المستخدم $id';

    await _addHistory(
      name: name,
      id: id,
      incoming: false,
    );

    RtcCallManager.instance.startListening();

    await RtcCallManager.instance.startCall(
      targetId: id,
    );

    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => CallScreen(
          name: name,
          id: id,
        ),
      ),
    );
  }

  @override
  void dispose() {
    callIdController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFF050505),
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          title: const Text(
            'CN CALL',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              letterSpacing: 1.5,
            ),
          ),
          actions: [
            IconButton(
              tooltip: 'تسجيل الخروج',
              onPressed: () async {
                final navigator = Navigator.of(context);

                final shouldLogout = await showDialog<bool>(
                  context: context,
                  builder: (dialogContext) {
                    return AlertDialog(
                      backgroundColor: const Color(0xFF151515),
                      title: const Text(
                        'تسجيل الخروج',
                        textDirection: TextDirection.rtl,
                      ),
                      content: const Text(
                        'هل تريد تسجيل الخروج من الحساب الحالي؟',
                        textDirection: TextDirection.rtl,
                      ),
                      actions: [
                        TextButton(
                          onPressed: () =>
                              Navigator.pop(dialogContext, false),
                          child: const Text('إلغاء'),
                        ),
                        FilledButton(
                          onPressed: () =>
                              Navigator.pop(dialogContext, true),
                          style: FilledButton.styleFrom(
                            backgroundColor: Colors.red,
                          ),
                          child: const Text('تسجيل الخروج'),
                        ),
                      ],
                    );
                  },
                );

                if (shouldLogout != true || !mounted) return;

                await CallSession.instance.logout();

                if (!mounted) return;

                navigator.pushAndRemoveUntil(
                  MaterialPageRoute(
                    builder: (_) => const LoginScreen(),
                  ),
                  (route) => false,
                );
              },
              icon: const Icon(Icons.logout_outlined),
            ),
          ],
        ),
        body: SafeArea(
          child: _loadingData
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(
                    20,
                    10,
                    20,
                    30,
                  ),
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.stretch,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(22),
                        decoration: BoxDecoration(
                          color: const Color(0xFF151515),
                          borderRadius:
                              BorderRadius.circular(24),
                          border: Border.all(
                            color: const Color(0xFF00E676)
                                .withValues(alpha: .18),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              width: 58,
                              height: 58,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: const Color(0xFF00E676)
                                    .withValues(alpha: .12),
                              ),
                              child: const Icon(
                                Icons.person,
                                color: Color(0xFF00E676),
                                size: 30,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  const Text(
                                    'مرحبًا بك',
                                    style: TextStyle(
                                      color: Colors.grey,
                                      fontSize: 13,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    CallSession.instance
                                            .displayName ??
                                        'مستخدم CN CALL',
                                    style: const TextStyle(
                                      color: Colors.white,
                                      fontSize: 22,
                                      fontWeight:
                                          FontWeight.w800,
                                    ),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'ID: ${CallSession.instance.userId ?? ''}',
                                    style: const TextStyle(
                                      color:
                                          Color(0xFF00E676),
                                      fontSize: 13,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(height: 28),

                      const Text(
                        'إجراء مكالمة',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.w800,
                        ),
                      ),

                      const SizedBox(height: 8),

                      Text(
                        'أدخل ID المستخدم الذي تريد الاتصال به',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 14,
                        ),
                      ),

                      const SizedBox(height: 16),

                      _Field(
                        controller: callIdController,
                        label: 'ID المستخدم',
                        hint: 'مثال: 2',
                        icon: Icons.badge_outlined,
                        keyboardType:
                            TextInputType.number,
                      ),

                      const SizedBox(height: 14),

                      _PrimaryButton(
                        text: 'بدء المكالمة',
                        onPressed: startCall,
                      ),

                      const SizedBox(height: 30),

                      Row(
                        mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'جهات الاتصال',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          TextButton.icon(
                            onPressed: _addContact,
                            icon: const Icon(
                              Icons.person_add_alt_1,
                              size: 18,
                            ),
                            label: const Text('إضافة'),
                          ),
                        ],
                      ),

                      const SizedBox(height: 8),

                      if (_contacts.isEmpty)
                        _EmptyState(
                          icon: Icons.contacts_outlined,
                          text: 'لا توجد جهات اتصال',
                        )
                      else
                        ..._contacts.map(
                          (contact) => _ContactItem(
                            name: contact['name']!,
                            id: contact['id']!,
                            online: false,
                            onDelete: () =>
                                _deleteContact(
                              contact['id']!,
                            ),
                            onCall: () async {
                              callIdController.text =
                                  contact['id']!;

                              await startCall();
                            },
                          ),
                        ),

                      const SizedBox(height: 24),

                      Row(
                        mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                        children: [
                          const Text(
                            'آخر المكالمات',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          if (_callHistory.isNotEmpty)
                            TextButton(
                              onPressed: _clearHistory,
                              child: const Text('مسح السجل'),
                            ),
                        ],
                      ),

                      const SizedBox(height: 8),

                      if (_callHistory.isEmpty)
                        _EmptyState(
                          icon: Icons.history,
                          text: 'لا يوجد سجل مكالمات',
                        )
                      else
                        ..._callHistory.take(20).map(
                          (item) => _CallHistoryItem(
                            name: item['name']?.toString() ??
                                'مستخدم CN CALL',
                            id: item['id']?.toString() ?? '',
                            time: item['time']?.toString() ??
                                '',
                            incoming:
                                item['incoming'] == true,
                          ),
                        ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final IconData icon;
  final String text;

  const _EmptyState({
    required this.icon,
    required this.text,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: const Color(0xFF151515),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            size: 36,
            color: Colors.grey.shade700,
          ),
          const SizedBox(height: 10),
          Text(
            text,
            style: TextStyle(
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }
}

Future<Map<String, String>?> _showAddContactDialog(
  BuildContext context,
) async {
  final idController = TextEditingController();
  final nameController = TextEditingController();

  final result = await showDialog<Map<String, String>>(
    context: context,
    builder: (dialogContext) {
      return Directionality(
        textDirection: TextDirection.rtl,
        child: AlertDialog(
          backgroundColor: const Color(0xFF151515),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(24),
          ),
          title: const Text(
            'إضافة جهة اتصال',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w800,
            ),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: idController,
                keyboardType: TextInputType.number,
                textDirection: TextDirection.ltr,
                decoration: InputDecoration(
                  labelText: 'ID المستخدم',
                  hintText: 'مثال: 2',
                  prefixIcon:
                      const Icon(Icons.badge_outlined),
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: nameController,
                decoration: const InputDecoration(
                  labelText: 'اسم المستخدم',
                  hintText: 'مثال: هشام',
                  prefixIcon:
                      Icon(Icons.person_outline),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () =>
                  Navigator.pop(dialogContext),
              child: const Text('إلغاء'),
            ),
            FilledButton.icon(
              onPressed: () {
                final id =
                    idController.text.trim();
                final name =
                    nameController.text.trim();

                if (id.isEmpty ||
                    int.tryParse(id) == null ||
                    name.isEmpty) {
                  ScaffoldMessenger.of(context)
                      .showSnackBar(
                    const SnackBar(
                      content: Text(
                        'أدخل ID صحيحًا واسم المستخدم',
                      ),
                    ),
                  );
                  return;
                }

                Navigator.pop(
                  dialogContext,
                  {
                    'id': id,
                    'name': name,
                  },
                );
              },
              icon: const Icon(
                Icons.person_add_alt_1,
              ),
              label: const Text('إضافة'),
              style: FilledButton.styleFrom(
                backgroundColor:
                    const Color(0xFF00E676),
                foregroundColor: Colors.black,
              ),
            ),
          ],
        ),
      );
    },
  );

  idController.dispose();
  nameController.dispose();

  return result;
}

class _ContactItem extends StatelessWidget {
  final String name;
  final String id;
  final bool online;
  final VoidCallback onDelete;
  final VoidCallback onCall;

  const _ContactItem({
    required this.name,
    required this.id,
    required this.online,
    required this.onDelete,
    required this.onCall,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      decoration: BoxDecoration(
        color: const Color(0xFF151515),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: Colors.white.withValues(alpha: .04),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF00E676)
                  .withValues(alpha: .10),
            ),
            child: const Icon(
              Icons.person,
              color: Color(0xFF00E676),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'ID: $id',
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          IconButton(
            tooltip: 'اتصال',
            onPressed: onCall,
            icon: const Icon(
              Icons.call,
              color: Color(0xFF00E676),
            ),
          ),
          IconButton(
            tooltip: 'حذف',
            onPressed: () async {
              final confirmed =
                  await showDialog<bool>(
                context: context,
                builder: (dialogContext) {
                  return AlertDialog(
                    backgroundColor:
                        const Color(0xFF151515),
                    title: const Text(
                      'حذف جهة الاتصال',
                      textDirection:
                          TextDirection.rtl,
                    ),
                    content: Text(
                      'هل تريد حذف $name؟',
                      textDirection:
                          TextDirection.rtl,
                    ),
                    actions: [
                      TextButton(
                        onPressed: () =>
                            Navigator.pop(
                          dialogContext,
                          false,
                        ),
                        child:
                            const Text('إلغاء'),
                      ),
                      FilledButton(
                        onPressed: () =>
                            Navigator.pop(
                          dialogContext,
                          true,
                        ),
                        style:
                            FilledButton.styleFrom(
                          backgroundColor:
                              Colors.red.shade800,
                        ),
                        child:
                            const Text('حذف'),
                      ),
                    ],
                  );
                },
              );

              if (confirmed == true) {
                onDelete();
              }
            },
            icon: const Icon(
              Icons.delete_outline,
              color: Colors.redAccent,
            ),
          ),
        ],
      ),
    );
  }
}

class IncomingCallScreen extends StatefulWidget {
  final String name;
  final String id;

  const IncomingCallScreen({
    super.key,
    required this.name,
    required this.id,
  });

  @override
  State<IncomingCallScreen> createState() => _IncomingCallScreenState();
}

class _IncomingCallScreenState extends State<IncomingCallScreen> {
  StreamSubscription<Map<String, dynamic>>? _subscription;
  bool _closed = false;

  @override
  void initState() {
    super.initState();

    _subscription = CallSession.instance.socket.messages.listen((message) {
      final type = message['type']?.toString();
      final fromId = message['from_id']?.toString();

      if ((type == 'hangup' || type == 'call_reject') &&
          (fromId == null || fromId == widget.id)) {
        _closeIncomingScreen();
      }
    });
  }

  void _closeIncomingScreen() {
    if (_closed || !mounted) return;

    _closed = true;
    _subscription?.cancel();
    _subscription = null;

    Navigator.of(context).pop();
  }

  Future<void> acceptCall(BuildContext context) async {
    RtcCallManager.instance.startListening();

    await RtcCallManager.instance.acceptCall(
      callerId: widget.id,
    );

    if (!context.mounted) return;

    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => CallScreen(
          name: widget.name,
          id: widget.id,
        ),
      ),
    );
  }

  Future<void> rejectCall(BuildContext context) async {
    RtcCallManager.instance.startListening();

    await RtcCallManager.instance.rejectCall(
      callerId: widget.id,
    );

    if (!context.mounted) return;

    Navigator.pop(context);
  }

  @override
  void dispose() {
    _subscription?.cancel();
    _subscription = null;
    _closed = true;
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFF050505),
        body: SafeArea(
          child: Column(
            children: [
              const SizedBox(height: 50),

              Text(
                'مكالمة واردة',
                style: TextStyle(
                  color: Colors.grey.shade500,
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                ),
              ),

              const Spacer(),

              Container(
                width: 140,
                height: 140,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF00E676).withValues(alpha: .08),
                  border: Border.all(
                    color: const Color(0xFF00E676).withValues(alpha: .35),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF00E676).withValues(alpha: .12),
                      blurRadius: 40,
                      spreadRadius: 10,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.person,
                  size: 68,
                  color: Color(0xFF00E676),
                ),
              ),

              const SizedBox(height: 28),

              Text(
                widget.name,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                'ID: ${widget.id}',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 13,
                ),
              ),

              const SizedBox(height: 16),

              Text(
                'يتصل بك الآن...',
                style: TextStyle(
                  color: Colors.grey.shade500,
                  fontSize: 14,
                ),
              ),

              const Spacer(),

              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Column(
                    children: [
                      GestureDetector(
                        onTap: () => rejectCall(context),
                        child: Container(
                          width: 70,
                          height: 70,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Colors.red.shade700,
                            boxShadow: [
                              BoxShadow(
                                color: Colors.red.withValues(alpha: .20),
                                blurRadius: 25,
                                spreadRadius: 3,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.call_end,
                            color: Colors.white,
                            size: 32,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'رفض',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),

                  Column(
                    children: [
                      GestureDetector(
                        onTap: () => acceptCall(context),
                        child: Container(
                          width: 70,
                          height: 70,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: const Color(0xFF00C853),
                            boxShadow: [
                              BoxShadow(
                                color: const Color(0xFF00E676)
                                    .withValues(alpha: .22),
                                blurRadius: 25,
                                spreadRadius: 3,
                              ),
                            ],
                          ),
                          child: const Icon(
                            Icons.call,
                            color: Colors.white,
                            size: 32,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'قبول',
                        style: TextStyle(
                          color: Colors.grey.shade600,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ],
              ),

              const SizedBox(height: 55),

              Text(
                'CN CALL',
                style: TextStyle(
                  color: Colors.grey.shade800.withValues(alpha: .45),
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 2,
                ),
              ),

              const SizedBox(height: 28),
            ],
          ),
        ),
      ),
    );
  }
}

class CallScreen extends StatefulWidget {
  final String name;
  final String id;

  const CallScreen({
    super.key,
    required this.name,
    required this.id,
  });

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  bool muted = false;
  bool speaker = false;
  bool connected = false;
  int seconds = 0;

  StreamSubscription<Map<String, dynamic>>? _subscription;
  Timer? _timer;

  @override
  void initState() {
    super.initState();

    final manager = RtcCallManager.instance;

    manager.onConnected = () {
      if (!mounted) return;

      setState(() {
        connected = true;
      });

      _startTimer();
    };

    manager.onDisconnected = () {
      if (!mounted) return;

      setState(() {
        connected = false;
      });

      _timer?.cancel();
    };

    _subscription = manager.session.socket.messages.listen((message) {
      final type = message['type']?.toString();

      if (type == 'hangup' || type == 'call_reject') {
        if (!mounted) return;

        _timer?.cancel();

        Navigator.of(context).pop();
      }
    });

    if (manager.inCall) {
      connected = true;
      _startTimer();
    }
  }

  void _startTimer() {
    if (_timer != null) return;

    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (_) {
        if (!mounted || !connected) return;

        setState(() {
          seconds++;
        });
      },
    );
  }

  String get durationText {
    final minutes = seconds ~/ 60;
    final remainingSeconds = seconds % 60;

    return '${minutes.toString().padLeft(2, '0')}:'
        '${remainingSeconds.toString().padLeft(2, '0')}';
  }

  Future<void> toggleMute() async {
    final value = !muted;

    await RtcCallManager.instance.mute(value);

    if (!mounted) return;

    setState(() {
      muted = value;
    });
  }

  Future<void> toggleSpeaker() async {
    final value = !speaker;

    await RtcCallManager.instance.rtc.setSpeaker(value);

    if (!mounted) return;

    setState(() {
      speaker = value;
    });
  }

  Future<void> endCall() async {
    await RtcCallManager.instance.hangup();

    if (!mounted) return;

    Navigator.pop(context);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _subscription?.cancel();

    RtcCallManager.instance.onConnected = null;
    RtcCallManager.instance.onDisconnected = null;

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFF050505),
        body: SafeArea(
          child: Stack(
            children: [
              Positioned(
                left: 0,
                top: 0,
                width: 1,
                height: 1,
                child: IgnorePointer(
                  child: Opacity(
                    opacity: 0.01,
                    child: RTCVideoView(
                      RtcCallManager.instance.rtc.remoteRenderer,
                      objectFit:
                          RTCVideoViewObjectFit.RTCVideoViewObjectFitContain,
                    ),
                  ),
                ),
              ),

              Column(
                children: [
                  const SizedBox(height: 24),

              Row(
                children: [
                  IconButton(
                    onPressed: endCall,
                    icon: const Icon(
                      Icons.keyboard_arrow_down,
                      color: Colors.white,
                      size: 30,
                    ),
                  ),
                  const Expanded(
                    child: Center(
                      child: Text(
                        'CAFEE NET',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          letterSpacing: 1.5,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),

              const Spacer(),

              Container(
                width: 128,
                height: 128,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFF00E676).withValues(alpha: .08),
                  border: Border.all(
                    color: const Color(0xFF00E676).withValues(alpha: .35),
                    width: 2,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF00E676).withValues(alpha: .12),
                      blurRadius: 35,
                      spreadRadius: 8,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.person,
                  size: 62,
                  color: Color(0xFF00E676),
                ),
              ),

              const SizedBox(height: 28),

              Text(
                widget.name,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 27,
                  fontWeight: FontWeight.w800,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                'ID: ${widget.id}',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 13,
                ),
              ),

              const SizedBox(height: 18),

              Text(
                durationText,
                style: const TextStyle(
                  color: Color(0xFF00E676),
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1.5,
                ),
              ),

              const SizedBox(height: 8),

              AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: Text(
                  connected ? 'متصل الآن' : 'جاري الاتصال...',
                  key: ValueKey(connected),
                  style: TextStyle(
                    color: connected
                        ? const Color(0xFF00E676)
                        : Colors.grey.shade500,
                    fontSize: 14,
                    fontWeight: connected
                        ? FontWeight.w600
                        : FontWeight.normal,
                  ),
                ),
              ),

              const Spacer(),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 34),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    _CallControlButton(
                      icon: muted
                          ? Icons.mic_off
                          : Icons.mic_none,
                      label: muted ? 'إلغاء الكتم' : 'كتم',
                      active: muted,
                      onPressed: toggleMute,
                    ),
                    _CallControlButton(
                      icon: speaker
                          ? Icons.volume_up
                          : Icons.volume_down,
                      label: 'مكبر الصوت',
                      active: speaker,
                      onPressed: toggleSpeaker,
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 34),

              GestureDetector(
                onTap: endCall,
                child: Container(
                  width: 70,
                  height: 70,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.red.shade700,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.red.withValues(alpha: .22),
                        blurRadius: 25,
                        spreadRadius: 3,
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.call_end,
                    color: Colors.white,
                    size: 32,
                  ),
                ),
              ),

              const SizedBox(height: 12),

              Text(
                'إنهاء المكالمة',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 12,
                ),
              ),

              const SizedBox(height: 38),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CallControlButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onPressed;

  const _CallControlButton({
    required this.icon,
    required this.label,
    required this.active,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        IconButton(
          onPressed: onPressed,
          style: IconButton.styleFrom(
            backgroundColor: active
                ? const Color(0xFF00E676).withValues(alpha: .18)
                : const Color(0xFF151515),
            foregroundColor: active
                ? const Color(0xFF00E676)
                : Colors.white,
            fixedSize: const Size(58, 58),
          ),
          icon: Icon(icon),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(
            color: Colors.grey.shade600,
            fontSize: 11,
          ),
        ),
      ],
    );
  }
}

class _CallHistoryItem extends StatelessWidget {
  final String name;
  final String id;
  final String time;
  final bool incoming;

  const _CallHistoryItem({
    required this.name,
    required this.id,
    required this.time,
    required this.incoming,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF151515),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF00E676).withValues(alpha: .10),
            ),
            child: Icon(
              incoming ? Icons.call_received : Icons.call_made,
              color: const Color(0xFF00E676),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 3),
                Text(
                  'ID: $id',
                  style: TextStyle(
                    color: Colors.grey.shade600,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Text(
            time,
            style: TextStyle(
              color: Colors.grey.shade600,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// REGISTER
// ============================================================

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final userIdController = TextEditingController();

  final usernameController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();

  bool hidePassword = true;
  bool hideConfirmPassword = true;

  @override
  void dispose() {
    userIdController.dispose();

    usernameController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    super.dispose();
  }

  Future<void> createAccount() async {
    final userId = userIdController.text.trim();
    final username = usernameController.text.trim();
    final password = passwordController.text;
    final confirmPassword = confirmPasswordController.text;

    if (userId.isEmpty ||
        username.isEmpty ||
        password.isEmpty ||
        confirmPassword.isEmpty) {
      _message('أكمل جميع البيانات');
      return;
    }

    if (int.tryParse(userId) == null) {
      _message('ID المستخدم يجب أن يكون أرقامًا فقط');
      return;
    }

    if (username.length < 3) {
      _message('اسم المستخدم يجب أن يكون 3 أحرف على الأقل');
      return;
    }

    if (password.length < 6) {
      _message('كلمة المرور يجب أن تكون 6 أحرف على الأقل');
      return;
    }

    if (password != confirmPassword) {
      _message('كلمتا المرور غير متطابقتين');
      return;
    }

    final result = await AccountApi.register(
      userId: userId,
      username: username,
      password: password,
    );

    if (!mounted) return;

    final success = result['success'] == true;
    final message =
        result['message']?.toString() ??
        (success
            ? 'تم إنشاء الحساب بنجاح'
            : 'تعذر إنشاء الحساب');

    _message(message, success: success);

    if (!success) return;

    await Future.delayed(const Duration(milliseconds: 700));

    if (!mounted) return;

    Navigator.pop(context);
  }

  void _message(String text, {bool success = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        backgroundColor:
            success ? const Color(0xFF00A85A) : Colors.red.shade800,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: const Icon(Icons.arrow_back),
          ),
        ),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 10, 24, 40),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: Column(
                  children: [
                    _Logo(),

                    const SizedBox(height: 22),

                    const Text(
                      'إنشاء حساب',
                      style: TextStyle(
                        fontSize: 30,
                        fontWeight: FontWeight.w800,
                      ),
                    ),

                    const SizedBox(height: 8),

                    Text(
                      'أنشئ حسابك في CN CALL',
                      style: TextStyle(
                        color: Colors.grey.shade500,
                        fontSize: 14,
                      ),
                    ),

                    const SizedBox(height: 34),

                    _Field(
                      controller: userIdController,
                      label: 'ID المستخدم',
                      hint: 'الرقم الذي تستخدمه لتسجيل الدخول والتواصل',
                      icon: Icons.badge_outlined,
                      keyboardType: TextInputType.number,
                    ),

                    const SizedBox(height: 16),

                    _Field(
                      controller: usernameController,
                      label: 'اسم المستخدم',
                      hint: 'الاسم الذي سيظهر للآخرين أثناء المكالمة',
                      icon: Icons.person_outline,
                    ),

                    const SizedBox(height: 16),

                    _Field(
                      controller: passwordController,
                      label: 'كلمة المرور',
                      hint: '6 أحرف على الأقل',
                      icon: Icons.lock_outline,
                      obscureText: hidePassword,
                      suffix: IconButton(
                        onPressed: () {
                          setState(() {
                            hidePassword = !hidePassword;
                          });
                        },
                        icon: Icon(
                          hidePassword
                              ? Icons.visibility_off
                              : Icons.visibility,
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    _Field(
                      controller: confirmPasswordController,
                      label: 'تأكيد كلمة المرور',
                      hint: 'أعد كتابة كلمة المرور',
                      icon: Icons.lock_reset_outlined,
                      obscureText: hideConfirmPassword,
                      suffix: IconButton(
                        onPressed: () {
                          setState(() {
                            hideConfirmPassword =
                                !hideConfirmPassword;
                          });
                        },
                        icon: Icon(
                          hideConfirmPassword
                              ? Icons.visibility_off
                              : Icons.visibility,
                        ),
                      ),
                    ),

                    const SizedBox(height: 24),

                    _PrimaryButton(
                      text: 'إنشاء الحساب',
                      onPressed: createAccount,
                    ),

                    const SizedBox(height: 16),

                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text(
                        'لدي حساب بالفعل',
                        style: TextStyle(
                          color: Color(0xFF00E676),
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    _Footer(),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

// ============================================================
// SHARED UI
// ============================================================

class _Logo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 88,
      height: 88,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: const Color(0xFF00E676).withValues(alpha: .10),
        border: Border.all(
          color: const Color(0xFF00E676),
          width: 2,
        ),
      ),
      child: const Icon(
        Icons.call,
        size: 40,
        color: Color(0xFF00E676),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hint;
  final IconData icon;
  final bool obscureText;
  final TextInputType? keyboardType;
  final Widget? suffix;

  const _Field({
    required this.controller,
    required this.label,
    required this.hint,
    required this.icon,
    this.obscureText = false,
    this.keyboardType,
    this.suffix,
  });

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      textDirection: TextDirection.ltr,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        prefixIcon: Icon(icon),
        suffixIcon: suffix,
        filled: true,
        fillColor: const Color(0xFF151515),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(
            color: Color(0xFF00E676),
          ),
        ),
      ),
    );
  }
}

class _PrimaryButton extends StatelessWidget {
  final String text;
  final VoidCallback onPressed;

  const _PrimaryButton({
    required this.text,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 56,
      child: FilledButton(
        onPressed: onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: const Color(0xFF00E676),
          foregroundColor: Colors.black,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(18),
          ),
        ),
        child: Text(
          text,
          style: const TextStyle(
            fontSize: 17,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

class _Footer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          'CAFEE NET',
          style: TextStyle(
            color: Colors.grey.shade800.withValues(alpha: .45),
            fontSize: 12,
            fontWeight: FontWeight.w700,
            letterSpacing: 2.2,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          'هشام الريمي',
          style: TextStyle(
            color: Colors.grey.shade800.withValues(alpha: .35),
            fontSize: 9,
            fontWeight: FontWeight.w500,
            letterSpacing: .8,
          ),
        ),
      ],
    );
  }
}
